# FP-trivia
Pointfree Programming Language with Combinators - this is **Lazy Version**,  (Strict Version --> [new](https://github.com/fp-system/fp-interpreter))

**This Repo will be deleted. choose the latest Repo -->** [fp-interpreter](https://github.com/fp-system/fp-interpreter)

Compile with Delphi (Community Edition Free)

**[de]** Ich habe mich einige Jahre mit Backus' FP beschäftigt, 
und einige Erfahrungen in dieses FP Projekt einfließen lassen.
Man könnte es damit vergleichen, dass Leibniz eine Rechenmaschiene baute 
und dann neue Ideen daraus entstanden sind. 
Ein bekannter Informatiker verbreitet auf Twitter, dass John Backus meinte 
er wäre mit FP gescheitert (und alle sollten bitte OOP verwenden). 
Aber ich sehe keinen Widerspruch zwischen FP und OOP. 
Nein - die können sogar sehr gut miteinander harmonieren, 
wenn man sich auf immutable Daten beschränkt. Das FP, 
daß ich nun vorstelle hat vieles mit Backus FP gemeinsam. 
Es ist immer noch ein "combinator based functional programming system", 
und ich verwende Fähigkeiten von FFP verbunden mit der Schönheit von FP, 
die John Backus im ersten Teil seines Aufsatzes vorstellte. 
Das AST-System von Backus habe ich allerdings mit einer Monadentechnik ersetzt, 
da es sonst die Sprache unnötig komplex machen würde, und außerdem eine mittlerweile 
akzeptierte Technik geworden ist. Eine Fortsetzung könnte ich mir aber mit 
algebraischen Effekten vorstellen. 
Ich setze auf die Infixnotation als einen grundlegenden Mechanismus, 
wie sie auch in der menschlichen Sprache verankert ist. 
Die Form "Subjekt Prädikat Objekt" wird also ungefähr als ein Tripel in einer Zelle 
dargestellt. (die Lisper verwenden cons-Zellen, ich verwende hier Tripel) 
Für die, die den Aufsatz von John Backus kennen, bringe ich nun eines seiner 
bekannten Beispiele, das Innere Produkt:

    IP == (+ \) ° (* aa) ° trans ° ee

Es ist eine Definition (==) des Namens mit einem Term. 
(\\) ist der insertr-Kombinator. 
(aa) ist der applytoall-Kombinator. 
(ee) bietet die Möglichkeit IP in Infixnotation zu verwenden:

    '(1;2;3;4;5;) IP '(10;20;30;40;50;)

Dabei ist 'x der Konstanten-Kombinator und (;) steht für Liste. 
Weiter verwende ich [i] als Selektoren, statt blanker Zahlen und #name für lokale Instanzenvariablen...

https://fp-system.github.io

**[PS]** \
Die funktionale Programmierung bietet immer mal wieder überraschende Erkenntnisse, \
und es gibt genügend Implementierungen (z.B. diese) um dies zu verifizieren. \
Zum Beispiel zum Thema Lazy-Evaluation, wie hier in einem [Brief an Herrn S.](https://github.com/Fpstefan/FP-trivia/blob/master/FP-Archive/LAZY-AS-LASY-CAN.md) \
Oder der Selbstbau einer [Lazy-Bombe](https://github.com/Fpstefan/FP-trivia/blob/master/FP-Archive/LazyBomb.pdf).
