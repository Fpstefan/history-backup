Hallo Herr S.,

Sie schrieben, daß Sie sich freuen würden weiter von mir zu hören.

Heute komme ich mit einer Problemstellung als Frage, \
welche mir aufgefallen ist zum Thema Lazy-Evaluation und \
Seiteneffekte (z.B. durch Monaden).

Es geht dabei um einen Seiteneffekt an einem Konstantenwert, \
der in einer Lazy-Funktion verwendet wird. \
Nennen Wir den Wert amp.

    amp == 3                        // Konstante, die bald geändert wird

    lazyfunc == ((amp*id) lazymap)  // Macht Produkte mit einer Lazy-Mapping-Funktion


    a := lazyfunc°from°1   // mit from°1 wird eine Lazy-Zahlenliste beginnend mit 1 erzeugt

    b := a take 5          // holt die ersten 5 Werte aus der Produktion
                           // ich denke mal (3 6 9 12 15)

    // dann kommt ein Seiteneffekt:
    [ändern von amp auf 10]

    c := a take 10         // müsste die Werte (3 6 9 12 15 18 21 24 27 30) liefern
                           // liefert aber     (3 6 9 12 15 60 70 80 90 100)

Was aber verständlich wäre in diesem einfachen Beispiel. \
Das legt den Verdacht nahe, daß Seiteneffekte in einem ungünstigen Fall zu \
fehlerhaften Daten in Lazy-Listen führen können.

Auf gewisse Seiteneffekte kann ich leider nicht verzichten. \
Muss ich dann auf die Lazy-Evaluation verzichten?

Viele Grüße, \
Stefan C.
