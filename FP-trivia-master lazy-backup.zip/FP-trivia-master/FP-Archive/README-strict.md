## FP-trivia-strict
prim-strict version --> [now](https://github.com/fp-system/fp-interpreter)

![triviamap](http://fpstefan.github.io/fpstefande/triviastrictmap.png)
