![FP-Logo](http://fpstefan.github.io/fpstefande/FPimage.png)

## Fita Projekt -- Interpreter für eine Programmiersprache im Kombinatorstil
\
Dieses Archiv bietet nur die Möglichkeit einer ZIP-Datei,\
ein Installer kann aber herunter geladen werden unter dem Link, [www.FP-System.org](https://www.fp-system.org/)

Das Fita Projekt orientiert sich etwas an dem Aufsatz von John Backus zu seiner Turingpreisverleihung mit dem Titel
> Can Programming Be Liberated from the von Neumann Style?\
> A Functional Style and Its Algebra of Programs, [PDF](https://www.thocp.net/biographies/papers/backus_turingaward_lecture.pdf)

Es gab aber auch andere Quellen wie [PLaSM](http://www.plasm.net/docs/tutorial/) oder das 
[FL Projekt](http://theory.stanford.edu/~aiken/publications/trs/RJ7100.pdf)
von denen ich mich in der Wahl der Funktionsnamen\
oder Ideen inspirieren lassen habe.\
Das Fita Projekt ist dennoch kein FL, sondern eher ein FP-System wie die ursprünglichen Ideen von John Backus.\
Auch verwende ich im Fita Projekt das Konzept einer **Monade**, um notwendige Seiteneffekte durchführen zu können.\
Seiteneffekte geschehen nur mit der Ausgabe der Monaden, auf keinen Fall aber in den Funktionen, in denen \
höchstens die Bindungen der Monaden aufgeführt sind.\
Damit ist FP eine **rein** funktionale Programmiersprache, die die referentielle Transparenz in den Funktionen einhält.\
John Backus lies sich in seinen FP-Systemen von der Programmiersprache [APL](https://en.wikipedia.org/wiki/APL_(programming_language)) inspirieren.\
Die grundlegende Regel in APL, **Rechts-vor-Links**, wird auch oft im Fita Projekt von den Kombinatoren in Infix-\
schreibweise verwendet.

### Funktionen und Kombinatoren in FP
\
Das Beispiel von John Backus zur Beschreibung von Compose, Map, Reduce und der Definition,

    Def IP = (/ +) ° (a ×) ° trans

... sieht im Fita Projekt so aus:

    IP == (+ \) ° (* aa) ° trans ° ee

das **ee** ist nur Luxus, um **IP** in Infixschreibweise verwenden zu können. So etwa,

    '(1;2;3;4;5;) IP '(10;20;30;40;50;)
    --> 550

Die Klammerungen mit den Semikolons sind Listen.\
In "standard.txt" sieht man eine Menge von Definitionen.\
\
E...break.
